<?php

namespace ruqqz;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\player\Player;

use pocketmine\world\Position;
use pocketmine\world\World;

use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use Broadcaster\Broadcaster;
//use pocketmine\item\enchantment\Enchantment;
//use pocketmine\item\enchantment\EnchantmentInstance;

//use pocketmine\item\Tool;
//use pocketmine\item\Armor;
use pocketmine\block\Block;

use pocketmine\event\block\BlockBreakEvent;

use pocketmine\utils\TextFormat as C;

use pocketmine\item\WrittenBook;

use onebone\economyapi\EconomyAPI;

use pocketmine\event\player\{PlayerInteractEvent, PlayerDeathEvent, PlayerMoveEvent, PlayerExhaustEvent};

use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\utils\Config;
use pocketmine\network\mcpe\protocol\Transferpacket;

use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\entity\EntityDamageEvent;

//use pocketmine\tile\Tile;
//use pocketmine\tile\Chest as ChestTile;
//use pocketmine\block\Chest as ChestBlock;

//use pocketmine\event\player\PlayerInteractEvent;

//use CortexPE\DiscordWebhookAPI\Message;
//use CortexPE\DiscordWebhookAPI\Webhook;
//use CortexPE\DiscordWebhookAPI\Embed;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase implements Listener {
    
    public function onDisable() : void {
        $this->getLogger()->info("Ativado");
   $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
        @mkdir($this->getDataFolder());
        
    }
    
    public function onCommand(CommandSender $player, Command $cmd, string $l, array $args) : bool {
        switch($cmd->getName()){
            case "youtuber":
                if($player instanceof Player) {
                    $this->youtuber($player);
                } else {
                    $player->sendMessage("Comando apenas in-game");
                }
                break;
        }
        return true;
    }
    
    public function youtuber(Player $player) {
        
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $player, ?int $data){
			
			if( !is_null($data)) {
				
				switch($data) {
					
		      case "0":
						
		       $this->divulgar($player);
						
		      break;					

               
              case "1":
						
			     $this->recompensa($player);
						
			   break;

				}
				
			}
			
		});
	
		$form->setTitle("§l§cYOUTUBER");
        $form->setContent("§r§7Olá se você está aqui é porque você é um youtuber/miniyt, aqui iremos te mostrar a aba de divulgação e recompensas por vídeo!");
    $form->addButton("§r§eDivulgação\n§r§eClique para prosseguir", 1, "https://freshcoal.com/images/user/95d3993f-7562-4864-9c5c-282b0674a382.png");
    $form->addButton("§r§bRecompensas\n§r§eClique para prosseguir", 1, "https://freshcoal.com/images/user/39670373-233c-4125-9160-39715c0241cf.png");
    
    $form->sendToPlayer($player);
    return $form;
    }
    
    public function divulgar(Player $player) {
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $player, ?int $data){
			
			if( !is_null($data)) {
				
				switch($data) {
					
					case "0":
                        
                     $this->divulg($player);
                        
				    break;
                        
                  case "1":
                  break;
					
				}
				
			}
			
		});
		
		$form->setTitle("§l§eDIVULGAÇÃO");
       $form->setContent("§7Olá, está aba é para divulgar seu vídeo gravado em nosso servidor, caso divulgueum vídeo que não seja de nosso servidor ou mande algum vídeo porno gráfico você irá perder sua tag. Tome cuidado ao utilizar este comando!");
       $form->addButton("§r§4Divulgue Aqui\n§r§eClique para prosseguir", 1, "https://freshcoal.com/images/user/9120f991-d4c6-414d-9a30-11dc4509fcca.png");
       $form->addButton("§r§cVoltar\n§r§eClique para prosseguir", 0, 'textures/ui/redX1');
    
    $form->sendToPlayer($player);
    return $form;

    }

    public function recompensa(Player $player) {
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $player, ?int $data){
			
			if( !is_null($data)) {
				
				switch($data) {

                  case "0":
                        
                    $this->youtuber($player);
                        
				    break;
					
				}
			}
			
		});
		
		$form->setTitle("§l§bRECOMPENSA");
       $form->setContent("§r§7Olá aqui você recebera a recompensapor cada vídeo gravado em nosso servidor, abaixo irei mostrar os requisitos mínimos para poder retirar a recompensa.\n\n Requisitos Mínimos \n\n§cMiniYT: 50 visualizações e 25 likes\n\n§4YouTuber: 200 visualizações é 100 likes\n\n    §r§eRecompensas: §r§cMiniYT §r§e1.5k de cash §r§4YouTuber §r§e3k de cash");
       $form->addButton("§r§cVoltar\n§r§eClique para prosseguir", 0, 'textures/ui/redX1');
    
    $form->sendToPlayer($player);
    return $form;
       
    }

        public function divulg(Player $player){
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createCustomForm(function(Player $p, $result){
            if($result === null){
                return;
            }
            if(trim($result[0]) === ""){
                $p->sendMessage("§cColoque um link antes!");
                return;
            }

            
            #Aqui voce coloca os codigos e acoes que vao acontecer quando o player digitar na Input abaixo, vou dar um exemplo:
           
            $this->getServer()->broadcastMessage("§l§eDIVULGAÇÃO\n §f-> §r§7O§c YouTuber §7{$p->getName()} está divulgando um vídeo/live no servidor!\n     §ahttp://youtu.be/{$result[0]}");
            
            });
			$form->setTitle("§l§eDIVULGAÇÃO");
			$form->addInput("Coloque o link aqui");
    
			$form->sendToPlayer($player);
              return $form;
		}
}